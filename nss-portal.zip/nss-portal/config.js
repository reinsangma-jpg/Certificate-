// Supabase browser-safe configuration.
// Replace these placeholders with your Supabase project's values.
// NEVER put a service-role/secret key in this file.
window.NSS_CONFIG = {
  SUPABASE_URL: 'https://YOUR-PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_PUBLIC_KEY'
};
