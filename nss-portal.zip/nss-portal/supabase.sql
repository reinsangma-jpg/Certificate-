-- NSS Volunteer Management & Identity Portal
-- Run this entire script in Supabase SQL Editor.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  class_name text,
  roll_no text,
  volunteer_status text not null default 'Volunteer' check (volunteer_status in ('Volunteer','Member')),
  date_of_birth date,
  college_name text,
  phone text,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Recreate policies safely if this script is rerun.
drop policy if exists "Users can read own profile" on public.profiles;
drop policy if exists "Users can insert own profile" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;

create policy "Users can read own profile"
on public.profiles for select
to authenticated
using (auth.uid() = id);

create policy "Users can insert own profile"
on public.profiles for insert
to authenticated
with check (auth.uid() = id);

create policy "Users can update own profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.email)
  on conflict (id) do update set
    full_name = excluded.full_name,
    email = excluded.email,
    updated_at = now();
  return new;
end;
$$;

-- Remove an existing trigger before recreating it.
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Optional helper index for admin-side reporting later; it does not change RLS.
create index if not exists profiles_email_idx on public.profiles(email);
