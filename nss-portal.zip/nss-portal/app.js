(() => {
  'use strict';
  const cfg = window.NSS_CONFIG || {};
  const hasConfig = cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes('YOUR-PROJECT') && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes('YOUR_');
  const sb = hasConfig && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
  const $ = id => document.getElementById(id);
  let currentUser = null, currentProfile = null;

  const toast = (message, type='ok') => { const el=document.createElement('div'); el.className=`toast ${type==='error'?'error':''}`; el.textContent=message; $('toast-region').appendChild(el); setTimeout(()=>el.remove(),4200); };
  const esc = v => (v ?? '').toString();
  const initials = name => esc(name).trim().split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase() || 'N';
  const prettyDate = v => { if(!v) return 'Not provided'; const d=new Date(`${v}T00:00:00`); return Number.isNaN(d.getTime())?'Not provided':d.toLocaleDateString(undefined,{day:'2-digit',month:'short',year:'numeric'}); };
  const today = () => new Date().toLocaleDateString(undefined,{day:'2-digit',month:'long',year:'numeric'}).toUpperCase();
  const normalizeError = e => { const m=esc(e?.message||e||'Something went wrong.'); if(/already registered|already exists/i.test(m)) return 'An account with this email already exists.'; if(/invalid login credentials/i.test(m)) return 'Incorrect email or password.'; if(/password/i.test(m)&&/weak|short|characters/i.test(m)) return 'Password is too weak. Please use at least 8 characters.'; if(/email not confirmed/i.test(m)) return 'Please confirm your email before logging in.'; return m; };

  function requireConfig(){ if(!sb){ toast('Supabase is not configured yet. Add your URL and anon/public key in config.js.', 'error'); return false; } return true; }
  function showAuth(tab='login'){ $('auth-view').classList.remove('hidden'); $('app-view').classList.add('hidden'); document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.authTab===tab)); $('login-form').classList.toggle('hidden',tab!=='login'); $('signup-form').classList.toggle('hidden',tab!=='signup'); $('confirm-panel').classList.add('hidden'); }
  function showApp(){ $('auth-view').classList.add('hidden'); $('app-view').classList.remove('hidden'); }
  function setPage(page){ document.querySelectorAll('.page').forEach(p=>p.classList.remove('active-page')); $(`page-${page}`).classList.add('active-page'); document.querySelectorAll('.nav-item[data-page]').forEach(n=>n.classList.toggle('active',n.dataset.page===page)); history.replaceState(null,'',`#${page}`); $('sidebar').classList.remove('open'); }

  async function loadProfile(){
    if(!currentUser || !sb) return;
    const {data,error}=await sb.from('profiles').select('*').eq('id',currentUser.id).maybeSingle();
    if(error){ toast(`Could not load profile: ${error.message}`,'error'); return; }
    currentProfile=data || {id:currentUser.id,full_name:currentUser.user_metadata?.full_name||'',email:currentUser.email};
    if(!currentProfile.email) currentProfile.email=currentUser.email;
    renderAll();
  }
  function renderAll(){
    const p=currentProfile||{}; const name=p.full_name||currentUser?.user_metadata?.full_name||'Volunteer';
    ['welcome-name','top-user','side-name','profile-heading'].forEach(id=>{if($(id)) $(id).textContent=name;});
    $('side-email').textContent=currentUser?.email||p.email||'—'; $('profile-account-email').textContent=currentUser?.email||p.email||'—';
    const ini=initials(name); ['avatar-initial','id-initial','profile-initial'].forEach(id=>$(id).textContent=ini);
    $('id-name').textContent=name||'Not provided'; $('id-class').textContent=p.class_name||'Not provided'; $('id-roll').textContent=p.roll_no||'Not provided'; $('id-status').textContent=p.volunteer_status||'Volunteer'; $('id-dob').textContent=prettyDate(p.date_of_birth); $('id-college').textContent=p.college_name||'Not provided'; $('id-phone').textContent=p.phone||'Not provided'; $('id-email').textContent=currentUser?.email||p.email||'—';
    $('profile-name').value=p.full_name||name; $('profile-class').value=p.class_name||''; $('profile-roll').value=p.roll_no||''; $('profile-status').value=p.volunteer_status||'Volunteer'; $('profile-dob').value=p.date_of_birth||''; $('profile-college').value=p.college_name||''; $('profile-phone').value=p.phone||'';
    $('cert-name').textContent=name||'Volunteer Name'; $('cert-date').textContent=today();
  }

  async function login(e){ e.preventDefault(); if(!requireConfig())return; const email=$('login-email').value.trim(), password=$('login-password').value; if(!email||!password){toast('Please enter your email and password.','error');return;} const {data,error}=await sb.auth.signInWithPassword({email,password}); if(error){toast(normalizeError(error),'error');return;} currentUser=data.user; showApp(); await loadProfile(); setPage('dashboard'); toast('Welcome back.'); }
  async function signup(e){ e.preventDefault(); if(!requireConfig())return; const name=$('signup-name').value.trim(), email=$('signup-email').value.trim(), password=$('signup-password').value; if(!name||!email||password.length<8){toast('Enter your name, a valid email and a password of at least 8 characters.','error');return;} const redirect=`${location.origin}${location.pathname}`; const {data,error}=await sb.auth.signUp({email,password,options:{data:{full_name:name},emailRedirectTo:redirect}}); if(error){toast(normalizeError(error),'error');return;} if(data.user){ $('signup-form').classList.add('hidden'); $('login-form').classList.add('hidden'); $('confirm-panel').classList.remove('hidden'); toast('Confirmation email sent.'); } }
  async function resetPassword(e){ e.preventDefault(); if(!requireConfig())return; const email=$('reset-email').value.trim(); if(!email){toast('Enter your account email.','error');return;} const redirect=`${location.origin}${location.pathname}#reset`; const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:redirect}); if(error){toast(normalizeError(error),'error');return;} $('reset-dialog').close(); toast('Password reset link sent. Check your email.'); }
  async function logout(){if(sb) await sb.auth.signOut(); currentUser=null;currentProfile=null;showAuth('login');toast('You have been logged out.');}

  async function saveProfile(e){e.preventDefault();if(!requireConfig()||!currentUser)return;const payload={id:currentUser.id,full_name:$('profile-name').value.trim(),email:currentUser.email,class_name:$('profile-class').value.trim(),roll_no:$('profile-roll').value.trim(),volunteer_status:$('profile-status').value,date_of_birth:$('profile-dob').value||null,college_name:$('profile-college').value.trim(),phone:$('profile-phone').value.trim(),updated_at:new Date().toISOString()};if(!payload.full_name){toast('Name is required.','error');return;}const {data,error}=await sb.from('profiles').upsert(payload).select().single();if(error){toast(`Could not save profile: ${error.message}`,'error');return;}currentProfile=data;renderAll();toast('Profile saved and identity card refreshed.');}

  function certificateReady(){ if(!currentProfile?.full_name){toast('Please complete your profile name first.','error');return false;} const mobile=$('certificate-mobile').value.trim();if(!mobile){toast('Please enter a mobile number for this certificate request.','error');return false;}return true; }
  function fillFormSubmit(){const p=currentProfile||{}, contact=$('certificate-mobile').value.trim(); const map={"fs-subject":`NSS Participation Certificate Request - ${p.full_name||'Volunteer'}`,"fs-name":p.full_name,"fs-contact":contact,"fs-email":currentUser?.email||p.email,"fs-class":p.class_name,"fs-roll":p.roll_no,"fs-status":p.volunteer_status,"fs-dob":prettyDate(p.date_of_birth),"fs-college":p.college_name,"fs-profile-phone":p.phone,"fs-date":today()};Object.entries(map).forEach(([id,v])=>$(id).value=esc(v));}
  async function requestCertificate(){if(!certificateReady())return;fillFormSubmit();try{const form=$('formsubmit-form');const body=new URLSearchParams(new FormData(form));const res=await fetch('https://formsubmit.co/ajax/reinsangma@gmail.com',{method:'POST',headers:{Accept:'application/json','Content-Type':'application/x-www-form-urlencoded'},body});if(!res.ok)throw new Error(`FormSubmit returned ${res.status}`);toast('Certificate request submitted to the NSS office email.');}catch(err){toast('Could not submit the email request. Please try again later.','error');}}
  async function downloadCertificate(){if(!certificateReady()||!window.html2canvas){toast('Certificate generator is unavailable. Check your internet connection and try again.','error');return;}const node=$('certificate-canvas');try{const canvas=await html2canvas(node,{scale:3,useCORS:true,backgroundColor:'#fff',logging:false});const a=document.createElement('a');const safe=(currentProfile.full_name||'Volunteer').replace(/[^a-z0-9]+/gi,'-').replace(/^-|-$/g,'');a.download=`NSS-Participation-Certificate-${safe||'USER-NAME'}.png`;a.href=canvas.toDataURL('image/png');a.click();toast('Certificate PNG generated.');}catch(err){toast('Certificate generation failed. Please try again.','error');}}

  function bind(){
    document.querySelectorAll('[data-auth-tab]').forEach(b=>b.addEventListener('click',()=>showAuth(b.dataset.authTab)));
    $('login-form').addEventListener('submit',login);$('signup-form').addEventListener('submit',signup);$('forgot-btn').addEventListener('click',()=>{if(requireConfig())$('reset-dialog').showModal()});$('reset-form').addEventListener('submit',resetPassword);$('back-login').addEventListener('click',()=>showAuth('login'));$('logout-btn').addEventListener('click',logout);$('profile-form').addEventListener('submit',saveProfile);$('preview-cert').addEventListener('click',()=>{if(certificateReady()){$('certificate-canvas').scrollIntoView({behavior:'smooth',block:'center'});toast('Certificate preview updated.')}});$('request-cert').addEventListener('click',requestCertificate);$('download-cert').addEventListener('click',downloadCertificate);$('menu-toggle').addEventListener('click',()=>$('sidebar').classList.toggle('open'));
    document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>setPage(b.dataset.page)));
    window.addEventListener('hashchange',()=>{const h=location.hash.replace('#','');if(['dashboard','profile','certificate'].includes(h))setPage(h);});
  }
  async function boot(){bind(); if(!hasConfig){showAuth('login');toast('Add Supabase URL and anon/public key to config.js to activate authentication.','error');return;} const {data:{session}}=await sb.auth.getSession(); if(session?.user){currentUser=session.user;showApp();await loadProfile();setPage(['dashboard','profile','certificate'].includes(location.hash.slice(1))?location.hash.slice(1):'dashboard');}else showAuth('login'); sb.auth.onAuthStateChange(async (_event,session)=>{if(session?.user&&!currentUser){currentUser=session.user;showApp();await loadProfile();}else if(!session){currentUser=null;currentProfile=null;showAuth('login');}});}
  boot();
})();
